package com.gdomhid.concesionario.model.entity;

import android.os.Parcel;
import android.os.Parcelable;

public class Coche implements Parcelable {
    int id, referencia,km,cv,puertas,año;
    String titulo,precio,descripcion,ubicacion,combustible,cambio,color,imagenes;

    public Coche() {
    }

    public Coche(int id, int referencia, int km, int cv, int puertas, int año, String titulo,
                 String precio, String descripcion, String ubicacion, String combustible,
                 String cambio, String color, String imagenes) {
        this.id = id;
        this.referencia = referencia;
        this.km = km;
        this.cv = cv;
        this.puertas = puertas;
        this.año = año;
        this.titulo = titulo;
        this.precio = precio;
        this.descripcion = descripcion;
        this.ubicacion = ubicacion;
        this.combustible = combustible;
        this.cambio = cambio;
        this.color = color;
        this.imagenes = imagenes;
    }

    protected Coche(Parcel in) {
        id = in.readInt();
        referencia = in.readInt();
        km = in.readInt();
        cv = in.readInt();
        puertas = in.readInt();
        año = in.readInt();
        titulo = in.readString();
        precio = in.readString();
        descripcion = in.readString();
        ubicacion = in.readString();
        combustible = in.readString();
        cambio = in.readString();
        color = in.readString();
        imagenes = in.readString();
    }

    public static final Creator<Coche> CREATOR = new Creator<Coche>() {
        @Override
        public Coche createFromParcel(Parcel in) {
            return new Coche(in);
        }

        @Override
        public Coche[] newArray(int size) {
            return new Coche[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getReferencia() {
        return referencia;
    }

    public void setReferencia(int referencia) {
        this.referencia = referencia;
    }

    public int getKm() {
        return km;
    }

    public void setKm(int km) {
        this.km = km;
    }

    public int getCv() {
        return cv;
    }

    public void setCv(int cv) {
        this.cv = cv;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public String getCambio() {
        return cambio;
    }

    public void setCambio(String cambio) {
        this.cambio = cambio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getImagenes() {
        return imagenes;
    }

    public void setImagenes(String imagenes) {
        this.imagenes = imagenes;
    }

    @Override
    public String toString() {
        return "Coche{" +
                "id=" + id +
                ", refencia=" + referencia +
                ", km=" + km +
                ", cv=" + cv +
                ", puertas=" + puertas +
                ", año=" + año +
                ", titulo='" + titulo + '\'' +
                ", precio='" + precio + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", ubicacion='" + ubicacion + '\'' +
                ", combustible='" + combustible + '\'' +
                ", cambio='" + cambio + '\'' +
                ", color='" + color + '\'' +
                ", imagenes='" + imagenes + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeInt(referencia);
        parcel.writeInt(km);
        parcel.writeInt(cv);
        parcel.writeInt(puertas);
        parcel.writeInt(año);
        parcel.writeString(titulo);
        parcel.writeString(precio);
        parcel.writeString(descripcion);
        parcel.writeString(ubicacion);
        parcel.writeString(combustible);
        parcel.writeString(cambio);
        parcel.writeString(color);
        parcel.writeString(imagenes);
    }
}
