package com.gdomhid.concesionario.view.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gdomhid.concesionario.R;
import com.gdomhid.concesionario.model.entity.Coche;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import com.bumptech.glide.Glide;
import com.gdomhid.concesionario.view.activity.MainActivity;

public class CocheAdapter extends RecyclerView.Adapter<CocheViewHolder>{

    private ArrayList<Coche> cocheList;
    private Context context;

    public CocheAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public CocheViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_coche, parent, false);
        return new CocheViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CocheViewHolder holder, int position) {
        Coche coche2 = cocheList.get(position);
        holder.coche = coche2;
        holder.tvTitle.setText(coche2.getTitulo());
        holder.tvReferencia.setText(("Ref: "+coche2.getReferencia()));
        holder.tvPrecio.setText("Precio "+coche2.getPrecio());
        holder.tvCambio.setText("Cambio "+coche2.getCambio());
        holder.tvCombustible.setText("Combustible "+coche2.getCombustible());
        holder.tvCv.setText("Cv "+(coche2.getCv()));
        holder.tvAno.setText("Año "+(coche2.getAño()));
        holder.tvKm.setText("Km  "+coche2.getKm());
        String imgUrl = coche2.getImagenes();
        Glide.with(context).load(imgUrl).into(holder.ivPrincipal);
    }

    @Override
    public int getItemCount() {
        if(cocheList == null) {
            return 0;
        }
        return cocheList.size();
    }
    public void setCocheList(ArrayList<Coche> cocheList) {
        this.cocheList = cocheList;
    }
}
