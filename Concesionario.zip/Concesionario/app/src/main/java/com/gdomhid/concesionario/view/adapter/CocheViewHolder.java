package com.gdomhid.concesionario.view.adapter;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.gdomhid.concesionario.R;
import com.gdomhid.concesionario.model.entity.Coche;
import com.gdomhid.concesionario.view.activity.SecondFragment;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

public class CocheViewHolder extends RecyclerView.ViewHolder {

    public TextView tvTitle, tvPrecio,tvAno,tvKm,tvCv,tvCombustible,tvCambio,tvReferencia;
    public ImageView ivPrincipal;
    public Coche coche;

    public CocheViewHolder(@NonNull View itemView) {
        super(itemView);
        tvTitle = itemView.findViewById(R.id.tvTitle);
        tvPrecio = itemView.findViewById(R.id.tvPrecio);
        tvAno = itemView.findViewById(R.id.tvAno);
        tvKm = itemView.findViewById(R.id.tvKm);
        tvCv = itemView.findViewById(R.id.tvCv);
        tvCombustible = itemView.findViewById(R.id.tvCombustible);
        tvCambio = itemView.findViewById(R.id.tvCambio);
        tvReferencia = itemView.findViewById(R.id.tvReferencia);
        ivPrincipal = itemView.findViewById(R.id.ivProfile);

        itemView.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putParcelable("coche", coche);
            Navigation.findNavController(v).navigate(R.id.action_FirstFragment_to_SecondFragment,bundle);
        });
    }
}
